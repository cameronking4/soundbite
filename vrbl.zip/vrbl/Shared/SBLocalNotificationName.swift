//
//  LocalNotification.swift
//  SoundBite
//

import Foundation

extension NSNotification.Name {
    static let refreshAudioFiles = Notification.Name("SB_refreshAudioFiles")
}
